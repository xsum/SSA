﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsApplication1
{
    public partial class ChengJiXiuGai : Form
    {
        string strCon = "Server=92996974633A47E\\SQLEXPRESS;database=StudentCj;Integrated Security=true;";
        SqlConnection conn3;
        public ChengJiXiuGai()
        {
            InitializeComponent();
            conn3 = new SqlConnection(strCon);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "update cjbiao set cj='" + textBox2.Text + "' where id='" + textBox1.Text + "' and kcdm=(select kcdm from kecheng where kcmc='" + comboBox1.Text + "')";
                SqlCommand cmd = new SqlCommand(sql, conn3);
                conn3.Open();
                int aaa = cmd.ExecuteNonQuery();
                conn3.Close();
                if (aaa > 0)
                    MessageBox.Show("修改成功！");
                else
                {
                    MessageBox.Show("修改失败！");
                }

                textBox1.Text = "";
                comboBox1.Text = "";
                textBox2.Text = "";
            }

            catch
            {
                MessageBox.Show("对不起！修改不成功！");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}