﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection();
            con1.ConnectionString = "Server=92996974633A47E\\SQLEXPRESS;database=StudentCj;Integrated Security=true";
            string sql = "select Name,passwd from Admin where Name='" + textBox1.Text + "' and passwd='" + textBox2.Text + "'"; 
            SqlCommand com1 = new SqlCommand();
            com1.CommandText = sql;
            com1.Connection = con1;
            con1.Open();
            SqlDataReader sdr = com1.ExecuteReader();
            if (sdr.Read())
            {
                Main longs = new Main();
                longs.Show();
                con1.Close();
                this.Visible = false;
            }
            else 
            {
                MessageBox.Show("请输入正确用户和密码");
            }




        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            this.textBox2.Text = "";
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
            if (e.KeyCode == Keys.Escape)
            {
                button2.PerformClick();
            }
        }
    }
}