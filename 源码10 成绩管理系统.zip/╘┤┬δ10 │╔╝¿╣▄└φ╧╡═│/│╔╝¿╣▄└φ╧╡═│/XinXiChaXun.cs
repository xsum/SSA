﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication1
{
    public partial class XinXiChaXun : Form

    {

        string strConn = "Server=localhost; database=StudentCj; User=sa; Password=ok;";
        SqlConnection conn2;
        public XinXiChaXun()
        {
            InitializeComponent();
            conn2 = new SqlConnection(strConn);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlcxx = "SELECT  student.ID as 学号, student.Name as 姓名,BJ.BJMC as 班级名称 FROM BJ JOIN student ON BJ.BJDM = student.BJDM";
            DataSet dtst = new DataSet();
            SqlDataAdapter sdat = new SqlDataAdapter(sqlcxx,conn2);
            dtst.Clear();
            sdat.Fill(dtst,"student");
            dataGridView1.DataSource = dtst.Tables[0].DefaultView;
        }
    }
}