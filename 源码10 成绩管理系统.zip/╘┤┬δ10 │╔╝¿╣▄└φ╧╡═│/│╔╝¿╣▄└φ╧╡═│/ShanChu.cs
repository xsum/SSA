﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication1
{
    public partial class ShanChu : Form
    {
        string strCon = "Server=92996974633A47E\\SQLEXPRESS;database=StudentCj;Integrated Security=true;";　//连接数据库
        SqlConnection con;
        public ShanChu()
        {
            InitializeComponent();
            con = new SqlConnection(strCon);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql1 = "select * from cjbiao delete from cjbiao where id='" + textBox1.Text + "'";　　//删除学生成绩表中的信息
            string sql2 = "select * from student delete from student where id='" + textBox1.Text + "'";　//删除学生表中的信息
            SqlCommand com1 = new SqlCommand(sql1, con);
            SqlCommand com2 = new SqlCommand(sql2, con);
            con.Open();
            com1.ExecuteNonQuery();　　　//返回执行ＳＱＬ语句的影响行数
            com2.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("您确认删除吗！", "消息框", MessageBoxButtons.YesNo);
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}