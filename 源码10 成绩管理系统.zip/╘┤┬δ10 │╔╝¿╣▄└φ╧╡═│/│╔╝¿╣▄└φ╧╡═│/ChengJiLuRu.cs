﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication1
{
    public partial class ChengJiLuRu : Form
    {
        string str1 = "Server=localhost; database=StudentCj; user=sa; password=ok;";
        SqlConnection conn2;
        public ChengJiLuRu()
        {
            InitializeComponent();
            conn2 = new SqlConnection(str1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
                        try
            {
                //查询学号学号,班级代码,课程代码
                
                string sql1 = "SELECT  student.ID,BJ.BJDM,kecheng.KCDM FROM  BJ CROSS JOIN kecheng CROSS JOIN student where student.ID='" + textBox1.Text + "' and BJ.BJMC='" + comboBox2.Text + "' and kecheng.KCMC='" + comboBox1.Text + "'";
                DataSet da1 = new DataSet();    //把数据放在内存中
                SqlDataAdapter adp1 = new SqlDataAdapter(sql1, str1);   //更新数据库
                da1.Clear();   //清空数据
                adp1.Fill(da1);
                //将查询出的学号,班级代码,课程代码分别附值
                string ID = da1.Tables[0].Rows[0][0].ToString();  
                string BJDM = da1.Tables[0].Rows[0][1].ToString();
                string KCDM = da1.Tables[0].Rows[0][2].ToString();
                //录入成绩
                string sql = "insert into cjbiao(id,kcdm,bjdm,cj) values('" + ID + "','" + KCDM + "','" + BJDM + "','" + textBox3.Text + "')";

                SqlCommand cmd = new SqlCommand(sql, conn2);
                conn2.Open();
                cmd.ExecuteNonQuery();
                conn2.Close();


                MessageBox.Show("信息添加成功", "提示");

                textBox3.Text = "";

            }
            catch
            {
                MessageBox.Show("对不起！没有该学生的信息！操作失败！");
            }

           }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
    }
