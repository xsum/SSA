﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            this.Text = "学生信息管理系统";
            this.toolStripStatusLabel1.Text = "系统当前时间" + System.DateTime.Now.Year + "年" + System.DateTime.Now.Month + "月" + System.DateTime.Now.Day + "日" + System.DateTime.Now.Hour + ":" + System.DateTime.Now.Minute;

        }

        private void 推ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 学生信息输入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XinXiShuRu xxsr = new XinXiShuRu();
            xxsr.MdiParent = this;
            xxsr.Show();
        }

        private void 学生信息查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XinXiChaXun xxcx = new XinXiChaXun();
            xxcx.MdiParent = this;
            xxcx.Show();
        }

        private void 成绩输入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChengJiLuRu cjlr = new ChengJiLuRu();
            cjlr.MdiParent = this;
            cjlr.Show();
        }

        private void 成绩修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChengJiXiuGai cjxg = new ChengJiXiuGai();
            cjxg.MdiParent = this;
            cjxg.Show();
        }

      private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShanChu sc = new ShanChu();
            sc.MdiParent = this;
            sc.Show();
        }
        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GuanYu gy = new GuanYu();
            gy.MdiParent = this;
            gy.Show();
        }

        private void 成绩查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChengJiChaXun cjcx = new ChengJiChaXun();
            cjcx.MdiParent=this;
            cjcx.Show();
        }
    }
}