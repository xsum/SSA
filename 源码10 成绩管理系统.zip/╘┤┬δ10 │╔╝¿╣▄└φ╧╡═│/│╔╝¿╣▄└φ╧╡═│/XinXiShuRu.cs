﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication1
{
    public partial class XinXiShuRu : Form
    {

        string strcon = "Server=92996974633A47E\\SQLEXPRESS;database=StudentCj;Integrated Security=true";
        SqlConnection con;
        
        
        
        public XinXiShuRu()
        {
            InitializeComponent();
            con = new SqlConnection(strcon);
            
            

        }

        private void XinXiShuRu_Load(object sender, EventArgs e)
        {
          
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet sd = new DataSet();
                string sqlbj = "select bjdm from bj where bjmc='" + comboBox1.Text + "'";

                string id = "select id from studeng where id='" + textBox1 + "'";
                SqlDataAdapter sda = new SqlDataAdapter(id, con);
                sd.Clear();
                sda.Fill(sd, "id");
                if (sd.Tables[0].Rows.Count != 0)
                {
                    MessageBox.Show("你输入的信息有误");
                }
                else
                {
                    SqlDataAdapter sda1 = new SqlDataAdapter(sqlbj, con);
                    sd.Clear();
                    sda1.Fill(sd, "bjmc");
                    string bjcx = sd.Tables[0].Rows[0][0].ToString();
                    string sql = "insert into student values('" + textBox1.Text + "','" + textBox2.Text + "','" + bjcx + "')";
                    SqlCommand com = new SqlCommand(sql, con);
                    con.Open();
                    com.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("恭喜你！输入成功！");
                    textBox1.Text = "";
                    textBox2.Text = "";

                }



            }
            catch
            {

            }
        }


    }
}