﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsApplication1
{
    public partial class ChengJiChaXun : Form
    {
        string strConn = "Server=localhost; database=StudentCj;user=sa;password=ok;"; //连接数据  
        public ChengJiChaXun()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds;
                string sqla = "select a.id as 学号,b.name as 姓名,a.cj as 成绩, c.kcmc as 课程名称 from cjbiao a join student b on a.id=b.id join kecheng c on a.kcdm=c.kcdm where a.id='" + textBox1.Text + "' or b.name='" + textBox2.Text + "'";
                SqlDataAdapter adp = new SqlDataAdapter(sqla, strConn);
                ds = new DataSet();
                ds.Clear();
                adp.Fill(ds, "Cjbiao");
                //dataGridView1.DataSource = ds.Tables[0].DefaultView;
                if (ds.Tables[0].Rows.Count != 0)  //判断是否查询出
                {
                    dataGridView1.DataSource = ds.Tables[0].DefaultView;


                }
                else
                {
                    MessageBox.Show("对不起！你的成绩不存在，请输入正确的学号或姓名");

                }
            }
            catch
            { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds2;
                //string sql2 = "select a.id as 学号,b.name as 姓名,a.cj as 成绩, c.kcmc as 课程名称 from cjbiao a join student b on a.id=b.id join kecheng c on a.kcdm=c.kcdm where a.bjdm=(select bjdm from bj where bjmc='"+comboBj.Text+"')";
                string sql2 = "SELECT b.ID as 学号,d.Name as 姓名,a.BJMC as 班级名称,c.KCMC as 课程名称,b.CJ  as 成绩 FROM BJ a join cjbiao b ON a.BJDM =b.BJDM JOIN kecheng c ON b.KCDM =c.KCDM JOIN student d ON b.ID = d.ID where bjmc='" + comboBox1.Text + "'";
                SqlDataAdapter adp = new SqlDataAdapter(sql2, strConn);
                ds2 = new DataSet();
                ds2.Clear();
                adp.Fill(ds2, "Cjbiao1");
                //dataGridView1.DataSource = ds2.Tables[0].DefaultView;
                if (ds2.Tables[0].Rows.Count != 0)　　//判断是否查询出
                {
                    dataGridView1.DataSource = ds2.Tables[0].DefaultView;
                    textBox2.Text = "";
                    textBox1.Text = "";
                }
                else
                {
                    MessageBox.Show("对不起！你输入的班级的信息不存在，请输入正确的班级");
                    textBox1.Text = "";
                    textBox2.Text = "";

                }
            }
            catch
            { }
        }
    }
}